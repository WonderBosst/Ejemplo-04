export interface Calification {
    name?: string;
    coment?: string;
    calification: number;
    fecha: Date;
}
