export interface Category {
    idCategoryOK?: string;
    idCategoryBK: string;
}
